# ID: 79866754


def quicksort(array, start, end):
    if end - start > 1:
        p = partition(array, start, end)
        quicksort(array, start, p)
        quicksort(array, p + 1, end)


def partition(array, left, right):
    pivot = array[left]
    i = left + 1
    j = right - 1

    while True:
        while i <= j and array[i] <= pivot:
            i += 1
        while i <= j and array[j] >= pivot:
            j -= 1

        if i <= j:
            array[i], array[j] = array[j], array[i]
        else:
            array[left], array[j] = array[j], array[left]
            return j


def read_data():
    n = int(input())
    res = [[-int(completed), int(penalty), name]
           for name, completed, penalty
           in [input().strip().split() for _ in range(n)]]
    return res


def main():
    arr = read_data()
    quicksort(arr, 0, len(arr))

    for item in arr:
        print(item[-1])


if __name__ == '__main__':
    main()
